<?php
require_once ("./connect.php");
require_once ("./page.php");

if(empty($_GET['search'])){
  $sql = 'SELECT * FROM '.$table.' LIMIT 10 OFFSET '.$offset.'';
  $result = $db->query($sql);
  if (!$result) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    while ($row = $result->fetch_assoc()) {
      echo "<tr>";
      echo "<td><a id='pencil' class='btn btn-xs' href='?name=".$row['name']."&url=".$row['url']."&id=".$row['id']."&page=".$page."&content=".$table."'><i class='glyphicon glyphicon-pencil'></a></td>";
      echo "<td><a id='entryname' target='_blank' href='".$row['url']."'>".$row['name']."</a></td>";
      echo "<td>" .$row['url']. "</a></td>";
      echo "<td class='text-center'><a class='btn-xs' id='trash' href='?delid=".$row['id']."&name=del&page=".$page."&content=".$table."'><i class=' glyphicon glyphicon-trash'></a></td>";
      echo "<td><input type='checkbox' id='entrycheck'></td>";
      echo "</tr>";}}
  else {
    $searchcount = 0;
    $search = test_input($_GET['search']);
    $sql = 'SELECT * FROM '.$table.' WHERE name LIKE "%'.$search.'%" LIMIT 10 OFFSET '.$offset.'';
    $result = $db->query($sql);
    if (!$result) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      while ($row = $result->fetch_assoc()) {
        $searchcount ++;
        echo "<tr>";
        echo "<td><a id='pencil' class='btn btn-xs' href='?name=".$row['name']."&url=".$row['url']."&id=".$row['id']."&search=".$search."&content=".$table."'><i class='glyphicon glyphicon-pencil'></a></td>";
        echo "<td><a target='_blank' href='".$row['url']."'><strong>".$row['name']."</strong></td>";
        echo "<td>" .$row['url']. "</a></td>";
        echo "<td class='text-center'><a class='btn-xs' id='trash' href='?delid=".$row['id']."&name=del&search=".$search."&content=".$table."'><i class=' glyphicon glyphicon-trash'></a></td>";
        echo "<td><input type='checkbox' id='entrycheck'></td>";
        echo "</tr>";}}
?>
