<?php
require_once("./page.php");
require_once ("./connect.php");
  if(!empty($_SESSION['login_user'])){
/*_Standart wird gelistet_____________________________________________________*/
  echo "<p><a id='folder' href='?content=defaulttable'><i class='text-danger glyphicon glyphicon-tags'></i></a><span class='text-danger'> Default</span></p>";
  echo "<p><a id='folder' href='?content=Favoriten'><i class='text-warning glyphicon glyphicon-star'></i></a><span class='text-warning'> Favoriten</span></p>";
  echo "<p><a id='folder' href='newfolder.php?level=0'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></p>";
/*_FOLDER LEVEL 0_____________________________________________________________*/
  $sql01 = 'SELECT * FROM contentassign WHERE level = 0';
  $result01 = $db->query($sql01);
  if (!$result01) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    while ($row01 = $result01->fetch_assoc()) {
      $folder = $row01['id'];
      echo "
      <a id='folder' href='#".$row01['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a><span class='text-primary'> ".$row01['content']."</span>
      <ul class='collapse' id='".$row01['id']."'>";
/*_FOLDER LEVEL 1_____________________________________________________________*/
      //neuer Folder
      echo "<li><a id='folder' href='newtable.php?level=1'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></li>";
      $sql11 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 1 AND folder='.$folder.'';
      $result11 = $db->query($sql11);
      if (!$result11) {
        die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
        while ($row11 = $result11->fetch_assoc()) {
          $folder1 = $row11['id'];
          echo "
              <li>
                <a id='folder' href='#".$row11['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
                <span class='text-primary'> ".$row11['content']."</span>
              </li>
              <ul class='collapse' id='".$row11['id']."'>";
/*_TABELLEN LEVEL 2___________________________________________________________*/
          //neue Tabelle
          echo "<li><a id='folder' href='newtable.php?level=2'><i class='text-success glyphicon glyphicon-plus'></i></a><span class='text-success'> New Table</span></li>";
          //Tabellen lvl 2 werden gelistet
          $sql20 = 'SELECT * FROM contentassign WHERE type = 0 AND level = 2 AND folder='.$folder1.'';
          $result20 = $db->query($sql20);
          if (!$result20) {
            die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
            while ($row20 = $result20->fetch_assoc()) {
              echo "
                  <li>
                    <a id='folder' href='?content=".$row20['content']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a>
                    <span class='text-success'> ".$row20['content']."</span>
                  </li>";
            }
          echo "</ul>";
        }
/*_TABELLEN LEVEL 1___________________________________________________________*/
      //neue Tabelle
      echo "<li><a id='folder' href='newtable.php?level=1'><i class='text-success glyphicon glyphicon-plus'></i></a><span class='text-success'> New Table</span></li>";
      $sql10 = 'SELECT * FROM contentassign WHERE type = 0 AND folder='.$folder.'';
      $result10 = $db->query($sql10);
      if (!$result10) {
        die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
        while ($row10 = $result10->fetch_assoc()) {
          echo "<li><a id='folder' href='?content=".$row10['content']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a><span class='text-success'> ".$row10['content']."</span></li>";
        }
      echo "<p></ul></p>";
    }
  }else {
    echo "<p><a id='folder' href='?content=defaulttable'><i class='text-danger glyphicon glyphicon-tags'></i></a><span class='text-danger'> Default</span></p>";
    echo "<p><a id='folder' href='?content=Favoriten'><i class='text-warning glyphicon glyphicon-star'></i></a><span class='text-warning'> Favoriten</span></p>";
  /*_FOLDER LEVEL 0_____________________________________________________________*/
    $sql01 = 'SELECT * FROM contentassign WHERE level = 0';
    $result01 = $db->query($sql01);
    if (!$result01) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      while ($row01 = $result01->fetch_assoc()) {
        $folder = $row01['id'];
        echo "
        <a id='folder' href='#".$row01['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a><span class='text-primary'> ".$row01['content']."</span>
        <ul class='collapse' id='".$row01['id']."'>";


        $sql11 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 1 AND folder='.$folder.'';
        $result11 = $db->query($sql11);
        if (!$result11) {
          die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
          while ($row11 = $result11->fetch_assoc()) {
            $folder1 = $row11['id'];
            echo "
                <li>
                  <a id='folder' href='#".$row11['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
                  <span class='text-primary'> ".$row11['content']."</span>
                </li>
                <ul class='collapse' id='".$row11['id']."'>";
  /*_TABELLEN LEVEL 2___________________________________________________________*/
            //Tabellen lvl 2 werden gelistet
            $sql20 = 'SELECT * FROM contentassign WHERE type = 0 AND level = 2 AND folder='.$folder1.'';
            $result20 = $db->query($sql20);
            if (!$result20) {
              die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
              while ($row20 = $result20->fetch_assoc()) {
                echo "
                    <li>
                      <a id='folder' href='?content=".$row20['content']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a>
                      <span class='text-success'> ".$row20['content']."</span>
                    </li>";
              }
            echo "</ul>";
          }
  /*_TABELLEN LEVEL 1___________________________________________________________*/
        //neue Tabelle

        $sql10 = 'SELECT * FROM contentassign WHERE type = 0 AND folder='.$folder.'';
        $result10 = $db->query($sql10);
        if (!$result10) {
          die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
          while ($row10 = $result10->fetch_assoc()) {
            echo "<li><a id='folder' href='?content=".$row10['content']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a><span class='text-success'> ".$row10['content']."</span></li>";
          }
        echo "<p></ul></p>";
      }
  }
  ?>
