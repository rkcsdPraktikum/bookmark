<?php
require_once("./page.php");
require_once ("./connect.php");
  if(!empty($_SESSION['login_user'])){
  //Standart wird gelistet
  echo "<p><a id='folder' href='?content=defaulttable'><i class='text-danger glyphicon glyphicon-tags'></i></a><span class='text-danger'> Default</span></p>";
  echo "<p><a id='folder' href='?content=Favoriten'><i class='text-warning glyphicon glyphicon-star'></i></a><span class='text-warning'> Favoriten</span></p>";
  echo "<p><a id='folder' href='newfolder.php".$row['id']."'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></p>";
  //Folder werden gelistet
  $sql = 'SELECT * FROM contentassign WHERE level = 0';
  $result = $db->query($sql);
  if (!$result) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    while ($row = $result->fetch_assoc()) {
      $folder = $row['id'];
      echo "
      <a id='folder' href='#".$row['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a><span class='text-primary'> ".$row['content']."</span>
      <ul class='collapse' id='".$row['id']."'>";
      //neue Folder
      echo "<li><a id='folder' href='newtable.php".$row['id']."'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></li>";
      //Alle Folder werden gelistet
      $sql1 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 1 AND folder='.$folder.'';
      $result1 = $db->query($sql1);
      if (!$result1) {
        die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
        while ($row1 = $result1->fetch_assoc()) {
          $folder1 = $row1['id'];
          echo "
              <li>
                <a id='folder' href='#".$row1['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
                <span class='text-primary'> ".$row1['content']."</span>
              </li>
              <ul class='collapse' id='".$row1['id']."'>";
          //whileschleife ebene 2
          $sql_2 = 'SELECT * FROM contentassign WHERE type = 0 AND level = 2 AND folder='.$folder1.'';
          $result_2 = $db->query($sql_2);
          if (!$result_2) {
            die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
            while ($row_2 = $result_2->fetch_assoc()) {
              echo "
                  <li>
                    <a id='folder' href='?content=".$row_2['content']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a>
                    <span class='text-success'> ".$row_2['content']."</span>
                  </li>";
            }
          //ebene 2 ende
          echo "</ul>";
        }
      //neue Tabelle
      echo "<li><a id='folder' href='newtable.php?newtableid=".$row['id']."'><i class='text-success glyphicon glyphicon-plus'></i></a><span class='text-success'> New Table</span></li>";
      //Alle Tabellen werden gelistet
      $sql3 = 'SELECT * FROM contentassign WHERE type = 0 AND folder='.$folder.'';
      $result3 = $db->query($sql3);
      if (!$result3) {
        die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
        while ($row3 = $result3->fetch_assoc()) {
          echo "<li><a id='folder' href='?content=".$row3['content']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a><span class='text-success'> ".$row3['content']."</span></li>";
        }
      echo "<p></ul></p>";
    }
  }
  ?>
