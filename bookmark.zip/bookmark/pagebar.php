<?php

  if(!empty($_SESSION['login_user'])){
    echo '
      <div id="pagebarcontainer" style="background-color:#D9EDF7;" class="container-fluid">
        <div style="">
        <div class="col-sm-4">
          <form action="" class="" role="search">
            <div class="input-group">
              <input type="text" class="form-control" name="search" placeholder="Search...">
              <input type="text" class="hidden" name="content" value="<?php echo $table;?>">
              <span class="input-group-btn">
                <button class="btn btn-default" type="submit">
                  <span class="glyphicon glyphicon-search"></span>
                </button>
              </span>
            </div>
        	  </form>
        </div>
        <div class="col-sm-4 text-center">
          <span style="border-right-style:solid; border-width:thin; vertical-align:middle;" class="pagebar-btn-group">
            <a class="btn bg-info"><i class="glyphicon glyphicon-cog"></i></a>
            <a class="btn bg-info"><i class="glyphicon glyphicon-wrench"></i></a>
            <a class="btn bg-info"><i class="glyphicon glyphicon-flag"></i></a>
          </span>
          <span style=" vertical-align:middle;" class="pagebar-btn-group">
            <a class="btn bg-info"><i class="glyphicon glyphicon-cog"></i></a>
            <a class="btn bg-info"><i class="glyphicon glyphicon-wrench"></i></a>
          </span>
        </div>

        <div style="" class="text-right col-sm-4">';
          include_once('./pager.php');
        echo "</div>
        </div>
        </div>";
        }else {
          include_once('./bootstraplink.php');
          include ("./navbar.php");
         echo "<div id='profile' class='alert alert-success alert-warning'>
       <b class='glyphicon glyphicon-user'></b></b><b id='welcome' >Du Muass Anmelden um dieese seite  zu sehen!</b>
       </div>";
     echo "<body onload=\"setTimeout('history.back()', 2000);\">";
        }
          ?>
        </div>
      </div>
      </div>
