<?php
require_once('./connect.php');
require_once('./nav/page.php');

if(!empty($_GET['newurl'])){
  $newname = test_input($_GET['newname']);
  $newurl = test_input($_GET['newurl']);
  $db->query('INSERT INTO content (name, url, folder) VALUES ("'.$newname.'","'.$newurl.'","'.$folder.'")');
  echo "
      <div class='alert alert-success alert-dismissable' id='success-del'>
      <a class='close' data-dismiss='alert' aria-label='close'>&times;</a>
      <strong><i class='glyphicon glyphicon-floppy-saved'></i>  Eintrag gespeichert!</strong>
      <kbd class='bg-info text-success'> ".$newurl." </kbd> ,als <kbd class='bg-info text-success'>".$newname."</kbd>, in <kbd class='bg-info text-success'>".$folder."</kbd>
      </div>";
  }

if(!empty($_GET['editname'])){
  $editname = test_input($_GET['editname']);
  $id = test_input($_GET['id']);
  $db->query('UPDATE content   SET name = "'.$editname.'"  WHERE folder = '.$folder.' AND id ='.$id.' ');}
if(!empty($_GET['editurl'])){
  $editurl = test_input($_GET['editurl']);
  $id = test_input($_GET['id']);
  $db->query('UPDATE content   SET name = "'.$editname.'"  WHERE folder = '.$folder.' AND id ='.$id.' ');
  echo "
      <div class='alert alert-success alert-dismissable' id='success-del'>
      <a class='close' data-dismiss='alert' aria-label='close'>&times;</a>
      <strong><i class='glyphicon glyphicon-floppy-save'></i> Eintrag erfolgreich geändert!</strong>  <kbd class='bg-info text-success'> ".$_GET['editname']." </kbd> , <kbd class='bg-info text-success'>".$_GET['editurl']."</kbd>, in <kbd class='bg-info text-success'>".$folder."</kbd>
      </div>";}
?>
