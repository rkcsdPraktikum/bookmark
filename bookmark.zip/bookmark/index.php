
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
  <?php include_once('./style/style.php'); ?>
  <title>bookmark</title>
  <style>
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
  </style>
<body style="background-color:#222222;">
  <?php

  include('./login.php');

  include_once('./nav/page.php');


  if(!empty($_SESSION['login_user'])){
    include('./view.php');
    echo(4);
  }
  if(empty($_SESSION['login_user'])){

	include_once('./nav/navbar.php');

    include('./loginpage.php');

  }
  ?>
</head>
</body>
</html>
