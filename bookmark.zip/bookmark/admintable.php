<?php
require_once ("./connect.php");
require_once ("./page.php");
if(!empty($_SESSION['login_user'])){
$folder = $_GET['content'];
if(empty($_GET['search'])){
  $sql = 'SELECT * FROM content WHERE folder = '.$folder.' LIMIT 10 OFFSET '.$offset.'';
  $result = $db->query($sql);
  if (!$result) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    while ($row = $result->fetch_assoc()) {
      echo "<tr>";
      echo "<td><a id='pencil' class='btn btn-xs' href='?name=".$row['name']."&url=".$row['url']."&id=".$row['id']."&page=".$page."&content=".$folder."'><i class='glyphicon glyphicon-pencil'></a></td>";
      echo "<td><a class='btn btn-xs' href='";
              if($row['fav'] = 1){
                echo"?delfav=id=".$row['id']."'><i id='fav' class='glyphicon glyphicon-star fav";
              }
              else{
                echo"?fav=id=".$row['id']."'><i id='nofav' class='glyphicon glyphicon-star-empty";
              }
              echo"'></i></a>
              <a id='entryname' target='_blank' href='".$row['url']."'>".$row['name']."</a>
            </td>";
      echo "<td>" .$row['url']. "</a></td>";
      echo "<td class='text-center'><a class='btn-xs' id='trash' href='?delid=".$row['id']."&name=del&page=".$page."&content=".$folder."'><i class=' glyphicon glyphicon-trash'></a></td>";
      echo "<td><input type='checkbox' id='entrycheck'></td>";
      echo "</tr>";}}

  else {
    $searchcount = 0;
    $search = test_input($_GET['search']);
    $sql = 'SELECT * FROM '.$folder.' WHERE name LIKE "%'.$search.'%" LIMIT 10 OFFSET '.$offset.'';
    $result = $db->query($sql);
    if (!$result) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      while ($row = $result->fetch_assoc()) {
        $searchcount ++;
        echo "<tr>";
        echo "<td><a id='pencil' class='btn btn-xs' href='?name=".$row['name']."&url=".$row['url']."&id=".$row['id']."&search=".$search."&content=".$folder."'><i class='glyphicon glyphicon-pencil'></a></td>";
        echo "<td><a id='entryname' target='_blank' href='".$row['url']."'>".$row['name']."</a><a id='entryname' target='_blank' href='".$row['url']."'><i class='glyphicon glyphicon-star'></a></td>";
        echo "<td>" .$row['url']. "</a></td>";
        echo "<td class='text-center'><a class='btn-xs' id='trash' href='?delid=".$row['id']."&name=del&search=".$search."&content=".$folder."'><i class=' glyphicon glyphicon-trash'></a></td>";
        echo "<td><input type='checkbox' id='entrycheck'></td>";
        echo "</tr>";}}
      }if(empty($_SESSION['login_user'])){
          include_once('./bootstraplink.php');
         include ("./navbar.php");
        echo "<div id='profile' class='alert alert-success alert-warning'>
      <b class='glyphicon glyphicon-user'></b></b><b id='welcome' >Du Muass Anmelden um dieese seite  zu sehen!</b>
      </div>";
    echo "<body onload=\"setTimeout('history.back()', 2000);\">";
      }
?>
