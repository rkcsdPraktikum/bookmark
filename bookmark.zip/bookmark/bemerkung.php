<html>
	<head>
  <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <body style="background-color:#222222;"><br>
 <?php
 require_once('./init.php');

 $db = @new mysqli($db_servername, $db_username, $db_password, $db_database);
 if (mysqli_connect_errno()) {
     die ('Konnte keine Verbindung zur Datenbank aufbauen: '.mysqli_connect_error().'('.mysqli_connect_errno().')');
 }
$error = "
<div class='container'>
	<div class='containeook2/view.php?search=r row'>
	<div class='col-sm-10 col-sm-offset-2'>
	<a href='index.php'>
	<img class='img-thumbnail'  src='https://cdn.dribbble.com/users/605899/screenshots/4144886/pikabu.gif'>
</div>";

if(!empty($_GET['content'])){
  require("./connect.php");
	$comm = $_GET['content'];
	$bmid = $_GET['bmid'];
  $sql = 'SELECT `name` , `url`,`comment` FROM content WHERE id = "'.$bmid.'"';
  $result = $db->query($sql);
  if (!$result) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    while ($row = $result->fetch_assoc()) {
				if ($bmid > 'id') {
					echo $error;
echo $row['id'];
}else
echo "  <div class='jumbotron'>
    <div class='container text-left'>
    <h1>bookmark-".$row['name']."</h1>
      <p>readmarkable...</p>
    </div>
  </div>";

echo "<div class='container'>
  <div class='container row'>
<div class='col-sm-8 well col-sm-offset-2'>
 <p>".$row['comment']. "</p>
  </div><br>";

}}
if(empty($_GET['bmid'])){
	echo $error;
}
?><br><br>
  </body>
</html>
