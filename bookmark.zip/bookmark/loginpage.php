
  <div class="jumbotron">
    <div class="container text-left">
    <h1>bookmark</h1>
      <p>readmarkable...</p>
    </div>
  </div>
  <!--_MAINCONTAINER_________________________________________________________-->
  <div class="container">
  <div class="container row">
  <!--_CONTAINER_____________________________________________________________-->
  <div class="col-sm-4 col-sm-offset-4">
    <form class="" action="" target="_parent" method="post" >
      <div class="form-group well ">
        <div class="input-group">
          <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
          <input class="form-control" name="username" type="text" placeholder="Name" required>
        </div><br>
        <div class="input-group">
          <span class="input-group-addon"><i class="glyphicon glyphicon-sunglasses"></i></span>
          <input type="password"  class="form-control" name="password"  placeholder="Passwort" required><br>
        </div>
        <br>
      <button class="btn btn-primary" name="submit" type="submit" id="submit" value="Login"><i class="glyphicon glyphicon-log-in"></i> Anmelden</button>
    </div>
    </form>
    </div>
  <!--_CONTAINER_____________________________________________________________-->
</div>
</div>
