<?php
if (!empty($_POST['newnamepg'])) {
if (isset($_POST['submit4'])) {
	
require('../connect.php');
$newnamepg = $_POST['newnamepg'];
$newtext = $_POST['newtext']; 
$newpic = $_POST['newpic'];
   $pg = 'INSERT INTO pages (namepg,text,pic) VALUES ("'.$newnamepg.'","'.$newtext.'","'.$newpic.'")';
    $result = $db->query($pg);
if (!$result) {
  die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
  
    echo "<div class='alert alert-success alert-dismissable' id='success-del'>
        <a class='close' data-dismiss='alert' aria-label='close'>&times;</a>
        <strong><i class='glyphicon glyphicon-floppy-saved'></i>  Eintrag gespeichert!</strong> <kbd class='bg-info text-success'> ".$newnamepg." </kbd> 
         ,<kbd class='bg-info text-success'><a href='pages.php?pages=".$db->insert_id."'> ".$db->insert_id." </a></kbd> ,
         <kbd class='bg-info text-success'><a href='pages.php?pages=".$db->insert_id."'> Click mich um zu ihre seite gehen </a></kbd>
    </div>";
    
}}



?>
