<?php
if(!empty($_GET['search'])){
$searchcount = 0;
$search = test_input($_GET['search']);
$sql = 'SELECT * FROM content WHERE name LIKE "%'.$search.'%"';
$result = $db->query($sql);
if (!$result) {
  die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
  while ($row = $result->fetch_assoc()) {
    $searchcount ++;}

switch ($searchcount) {
  case '0':
  echo "
      <div class='alert alert-warning alert-dismissable' id='success-del'>
      <a class='close' data-dismiss='alert' aria-label='close'>&times;</a>
      <strong><i class='glyphicon glyphicon-search'></i> Keine Einträge gefunden zu  </strong><kbd class='bg-warning text-warning'>".$search."</kbd>
      </div>";
    break;
  case '1':
  echo "
      <div class='alert alert-success alert-dismissable' id='success-del'>
      <a class='close' data-dismiss='alert' aria-label='close'>&times;</a>
      <strong><i class='glyphicon glyphicon-search'></i> 1 Eintrag gefunden zu  </strong><kbd class='bg-info text-success'>".$search."</kbd>
      </div>";
    break;
  default:
  echo "
      <div class='alert alert-success alert-dismissable' id='success-del'>
      <a class='close' data-dismiss='alert' aria-label='close'>&times;</a>
      <strong><i class='glyphicon glyphicon-search'></i> ".$searchcount." Einträge gefunden zu  </strong><kbd class='bg-info text-success'>".$search."</kbd>
      </div>";
    break;
}}

?>
