<?php
require_once('./init.php');
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  $data = str_replace('"', '\"', $data);
  return $data;
}

$db = @new mysqli($db_servername, $db_username, $db_password, $db_database);
if (mysqli_connect_errno()) {
    die ('Konnte keine Verbindung zur Datenbank aufbauen: '.mysqli_connect_error().'('.mysqli_connect_errno().')');
}
?>
