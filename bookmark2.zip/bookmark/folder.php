
<?php
/* ---------------------------------------------------------------------------*
 *|  $Variable     0      0     | FOLDER LVL MIN++
 *|                ^      ^    | TABLE LVL MAX--
 *|              Level  Type    | FOLDER LVL MAX--
 * ---------------------------------------------------------------------------*/
require_once("./page.php");
require_once ("./connect.php");
if(!empty($_SESSION['login_user'])){
/*_Standart wird gelistet_____________________________________________________*/
  echo "<p><a id='folder' href='?content=defaulttable'><i class='text-danger glyphicon glyphicon-tags'></i></a><span class='text-danger'> Default</span></p>";
  echo "<p><a id='folder' href='?content=Favoriten'><i class='text-warning glyphicon glyphicon-star'></i></a><span class='text-warning'> Favoriten</span></p>";
  echo "<p><a id='folder' href='newfolder.php?level=0'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></p>";
/*_FOLDER LEVEL 0_____________________________________________________________*/
  //[0]Level [1]Type
  $sql01 = 'SELECT * FROM contentassign WHERE level = 0';
  $result01 = $db->query($sql01);
  if (!$result01) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row01 = $result01->fetch_assoc()) {
      $folder0 = $row01['id'];
      echo "
      <a id='folder' href='#".$row01['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a><span class='text-primary'> ".$row01['content']."</span>
      <ul class='collapse' id='".$row01['id']."'>";
/*_FOLDER LEVEL 1_____________________________________________________________*/
  //NEW [1]Level [1]Type
  echo "<li><a id='folder' href='newtable.php?level=1&contentlink=".$folder0."&type=1'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></li>";
  //[1]Level [1]Type
  $sql11 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 1 AND folder='.$folder0.'';
  $result11 = $db->query($sql11);
  if (!$result11) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row11 = $result11->fetch_assoc()) {
      $folder1 = $row11['id'];
      echo "
          <li>
            <a id='folder' href='#".$row11['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
            <span class='text-primary'> ".$row11['content']."</span>
          </li>
          <ul class='collapse' id='".$row11['id']."'>";
/*_FOLDER LEVEL 2_____________________________________________________________*/
  //NEW [2]Level [1]Type
  echo "<li><a id='folder' href='newtable.php?level=2&contentlink=".$folder1."&type=1'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></li>";
  //[2]Level [1]Type
  $sql12 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 2 AND folder='.$folder1.'';
  $result12 = $db->query($sql12);
  if (!$result12) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row12 = $result12->fetch_assoc()) {
      $folder2 = $row12['id'];
      echo "
          <li>
            <a id='folder' href='#".$row12['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
            <span class='text-primary'> ".$row12['content']."</span>
          </li>
          <ul class='collapse' id='".$row12['id']."'>";
/*_FOLDER LEVEL 3_____________________________________________________________*/
  //NEW [3]Level [1]Type
  echo "<li><a id='folder' href='newtable.php?level=2&contentlink=".$folder2."&type=1'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></li>";
  //[3]Level [1]Type
  $sql13 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 3 AND folder='.$folder2.'';
  $result13 = $db->query($sql13);
  if (!$result13) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row13 = $result13->fetch_assoc()) {
      $folder3 = $row13['id'];
      echo "
          <li>
            <a id='folder' href='#".$row13['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
            <span class='text-primary'> ".$row13['content']."</span>
          </li>
          <ul class='collapse' id='".$row13['id']."'>";
/*_TABELLEN LEVEL 4___________________________________________________________*/
  //NEW [4]Level [0]Type
  echo "<li><a id='folder' href='newtable.php?level=3&contentlink=".$folder3."&type=0'><i class='text-success glyphicon glyphicon-plus'></i></a><span class='text-success'> New Table</span></li>";
  //[4]Level [0]Type
  $sql40 = 'SELECT * FROM contentassign WHERE type = 0 AND level = 4 AND folder='.$folder3.'';
  $result40 = $db->query($sql40);
  if (!$result40) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row40 = $result40->fetch_assoc()) {
      echo "
          <li>
            <a id='folder' href='?content=".$row40['id']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a>
            <span class='text-success'> ".$row40['content']."</span>
          </li>";
    } //__END TAB LVL 4__

    echo "</ul>";
  } //__END FOLDER LVL 3__

/*_TABELLEN LEVEL 3___________________________________________________________*/
  //NEW [3]Level [0]Type
  echo "<li><a id='folder' href='newtable.php?level=3&contentlink=".$folder2."&type=0'><i class='text-success glyphicon glyphicon-plus'></i></a><span class='text-success'> New Table</span></li>";
  //[3]Level [0]Type
  $sql30 = 'SELECT * FROM contentassign WHERE type = 0 AND level = 3 AND folder='.$folder2.'';
  $result30 = $db->query($sql30);
  if (!$result30) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row30 = $result30->fetch_assoc()) {
      echo "
          <li>
            <a id='folder' href='?content=".$row30['id']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a>
            <span class='text-success'> ".$row30['content']."</span>
          </li>";
    } //__END TAB LVL 3__

    echo "</ul>";
  } //__END FOLDER LVL 2__

/*_TABELLEN LEVEL 2___________________________________________________________*/
  //NEW [2]Level [0]Type
  echo "<li><a id='folder' href='newtable.php?level=2&contentlink=".$folder1."&type=0'><i class='text-success glyphicon glyphicon-plus'></i></a><span class='text-success'> New Table</span></li>";
  //[2]Level [0]Type
  $sql20 = 'SELECT * FROM contentassign WHERE type = 0 AND level = 2 AND folder='.$folder1.'';
  $result20 = $db->query($sql20);
  if (!$result20) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row20 = $result20->fetch_assoc()) {
      echo "
          <li>
            <a id='folder' href='?content=".$row20['id']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a>
            <span class='text-success'> ".$row20['content']."</span>
          </li>";
    } //__END TAB LVL 2__

    echo "</ul>";
  } //__END FOLDER LVL 1__

/*_TABELLEN LEVEL 1___________________________________________________________*/
  //NEW [1]Level [0]Type
  echo "<li><a id='folder' href='newtable.php?level=1&contentlink=".$folder0."&type=0'><i class='text-success glyphicon glyphicon-plus'></i></a><span class='text-success'> New Table</span></li>";
  //[1]Level [0]Type
  $sql10 = 'SELECT * FROM contentassign WHERE type = 0 AND folder='.$folder0.'';
  $result10 = $db->query($sql10);
  if (!$result10) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row10 = $result10->fetch_assoc()) {
      echo "<li><a id='folder' href='?content=".$row10['id']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a><span class='text-success'> ".$row10['content']."</span></li>";
    } //__END TAB LVL 1__

    //CLOSE LIST
    echo "<p></ul></p>";

  } //__END FOLDER LVL 0__

}else{
  /*_Standart wird gelistet_____________________________________________________*/
    echo "<p><a id='folder' href='?content=defaulttable'><i class='text-danger glyphicon glyphicon-tags'></i></a><span class='text-danger'> Default</span></p>";
    echo "<p><a id='folder' href='?content=Favoriten'><i class='text-warning glyphicon glyphicon-star'></i></a><span class='text-warning'> Favoriten</span></p>";

  /*_FOLDER LEVEL 0_____________________________________________________________*/
    //[0]Level [1]Type
    $sql01 = 'SELECT * FROM contentassign WHERE level = 0';
    $result01 = $db->query($sql01);
    if (!$result01) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      //echo Content
      while ($row01 = $result01->fetch_assoc()) {
        $folder0 = $row01['id'];
        echo "
        <a id='folder' href='#".$row01['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a><span class='text-primary'> ".$row01['content']."</span>
        <ul class='collapse' id='".$row01['id']."'>";
  /*_FOLDER LEVEL 1_____________________________________________________________*/
    //[1]Level [1]Type
    $sql11 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 1 AND folder='.$folder0.'';
    $result11 = $db->query($sql11);
    if (!$result11) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      //echo Content
      while ($row11 = $result11->fetch_assoc()) {
        $folder1 = $row11['id'];
        echo "
            <li>
              <a id='folder' href='#".$row11['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
              <span class='text-primary'> ".$row11['content']."</span>
            </li>
            <ul class='collapse' id='".$row11['id']."'>";
  /*_FOLDER LEVEL 2_____________________________________________________________*/    //[2]Level [1]Type
    $sql12 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 2 AND folder='.$folder1.'';
    $result12 = $db->query($sql12);
    if (!$result12) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      //echo Content
      while ($row12 = $result12->fetch_assoc()) {
        $folder2 = $row12['id'];
        echo "
            <li>
              <a id='folder' href='#".$row12['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
              <span class='text-primary'> ".$row12['content']."</span>
            </li>
            <ul class='collapse' id='".$row12['id']."'>";
  /*_FOLDER LEVEL 3_____________________________________________________________*/    //[3]Level [1]Type
    $sql13 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 3 AND folder='.$folder2.'';
    $result13 = $db->query($sql13);
    if (!$result13) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      //echo Content
      while ($row13 = $result13->fetch_assoc()) {
        $folder3 = $row13['id'];
        echo "
            <li>
              <a id='folder' href='#".$row13['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
              <span class='text-primary'> ".$row13['content']."</span>
            </li>
            <ul class='collapse' id='".$row13['id']."'>";
  /*_TABELLEN LEVEL 4___________________________________________________________*/
    //[4]Level [0]Type
    $sql40 = 'SELECT * FROM contentassign WHERE type = 0 AND level = 4 AND folder='.$folder3.'';
    $result40 = $db->query($sql40);
    if (!$result40) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      //echo Content
      while ($row40 = $result40->fetch_assoc()) {
        echo "
            <li>
              <a id='folder' href='?content=".$row40['content']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a>
              <span class='text-success'> ".$row40['content']."</span>
            </li>";
      } //__END TAB LVL 4__

      echo "</ul>";
    } //__END FOLDER LVL 3__

  /*_TABELLEN LEVEL 3___________________________________________________________*/
    //[3]Level [0]Type
    $sql30 = 'SELECT * FROM contentassign WHERE type = 0 AND level = 3 AND folder='.$folder2.'';
    $result30 = $db->query($sql30);
    if (!$result30) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      //echo Content
      while ($row30 = $result30->fetch_assoc()) {
        echo "
            <li>
              <a id='folder' href='?content=".$row30['content']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a>
              <span class='text-success'> ".$row30['content']."</span>
            </li>";
      } //__END TAB LVL 3__

      echo "</ul>";
    } //__END FOLDER LVL 2__

  /*_TABELLEN LEVEL 2_________________________________________________________*/
   //[2]Level [0]Type
    $sql20 = 'SELECT * FROM contentassign WHERE type = 0 AND level = 2 AND folder='.$folder1.'';
    $result20 = $db->query($sql20);
    if (!$result20) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      //echo Content
      while ($row20 = $result20->fetch_assoc()) {
        echo "
            <li>
              <a id='folder' href='?content=".$row20['content']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a>
              <span class='text-success'> ".$row20['content']."</span>
            </li>";
      } //__END TAB LVL 2__

      echo "</ul>";
    } //__END FOLDER LVL 1__

  /*_TABELLEN LEVEL 1_________________________________________________________*/
    //[1]Level [0]Type
    $sql10 = 'SELECT * FROM contentassign WHERE type = 0 AND folder='.$folder0.'';
    $result10 = $db->query($sql10);
    if (!$result10) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      //echo Content
      while ($row10 = $result10->fetch_assoc()) {
        echo "<li><a id='folder' href='?content=".$row10['content']."'><i class='text-success glyphicon glyphicon-bookmark'></i></a><span class='text-success'> ".$row10['content']."</span></li>";
      } //__END TAB LVL 1__

      //CLOSE LIST
      echo "<p></ul></p>";

    } //__END FOLDER LVL 0__



}
  ?>
