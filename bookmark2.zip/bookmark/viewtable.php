<?php
require_once ("./connect.php");
require_once ("./page.php");
if(empty($_GET['search'])){
  $sql = 'SELECT * FROM content WHERE folder = '.$folder.' LIMIT 10 OFFSET '.$offset.'';
  $result = $db->query($sql);
  if (!$result) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    while ($row = $result->fetch_assoc()) {
      echo "<tr>";
      echo "<td><a target='_blank' href='".$row['url']."'><img  src='https://www.google.com/s2/favicons?domain=".$row['url']."'> " .$row['name']. "</td>";
      echo "<td>" .$row['url']. "</a></td>";
        echo "<td><a href='bemerkung.php?content=".$folder."&bmid=".$row['id']."'><i class='glyphicon glyphicon-list-alt'></i></a></td>";
      echo "<td></td>";
      echo "</tr>";}}
  else {
    $sql = 'SELECT * FROM '.$folder.' WHERE name LIKE "'.$_GET['search'].'"LIMIT 10 OFFSET '.$offset.'';
    $result = $db->query($sql);
    if (!$result) {
      die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
      while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td><a target='_blank' href='".$row['url']."'><img  src='https://www.google.com/s2/favicons?domain=".$row['url']."'> " .$row['name']. "</td>";
        echo "<td>" .$row['url']. "</a></td>";
          echo "<td><a href='bemerkung.php?content=".$folder."&bmid=".$row['id']."'><i class='glyphicon glyphicon-list-alt'></i></a></td>";
        echo "<td></td>";
        echo "</tr>";}}
?>
