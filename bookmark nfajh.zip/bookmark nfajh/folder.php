
<?php
/* ---------------------------------------------------------------------------*
 *|  $Variable     0      0     | FOLDER LVL MIN++
 *|                ^      ^    | TABLE LVL MAX--
 *|              Level  Type    | FOLDER LVL MAX--
 * ---------------------------------------------------------------------------*/
require_once("./nav/page.php");
require_once ("./connect.php");
if(!empty($_SESSION['login_user'])){
/*_Standart wird gelistet_____________________________________________________*/
  echo "<p><a id='folder' href='?content=defaulttable'><i class='text-danger glyphicon glyphicon-tags'></i></a><span class='text-danger'> Default</span></p>";
  echo "<p><a id='folder' href='?content=Favoriten'><i class='text-warning glyphicon glyphicon-star'></i></a><span class='text-warning'> Favoriten</span></p>";
  echo "<p><a id='folder' href='newfolder.php?level=0'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></p>";
/*_FOLDER LEVEL 0_____________________________________________________________*/
  //[0]Level [1]Type
  $sql01 = 'SELECT * FROM contentassign WHERE level = 0';
  $result01 = $db->query($sql01);
  if (!$result01) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row01 = $result01->fetch_assoc()) {
      $folder0 = $row01['id'];
      echo "
      <a id='folder' href='#".$row01['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
      <a id='folderlink' href='?content=".$row01['id']."'><span class='text-primary'> ".$row01['content']."</span></a>
      <ul class='collapse' id='".$row01['id']."'>";
/*_FOLDER LEVEL 1_____________________________________________________________*/
  //NEW [1]Level [1]Type
  echo "<li><a id='folder' href='newfolder.php?level=1&contentlink=".$folder0."&type=1'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></li>";
  //[1]Level [1]Type
  $sql11 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 1 AND folder='.$folder0.'';
  $result11 = $db->query($sql11);
  if (!$result11) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row11 = $result11->fetch_assoc()) {
      $folder1 = $row11['id'];
      echo "
          <li>
            <a id='folder' href='#".$row11['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
            <a id='folderlink' href='?content=".$row11['id']."'><span class='text-primary'> ".$row11['content']."</span></a>
          </li>
          <ul class='collapse' id='".$row11['id']."'>";
/*_FOLDER LEVEL 2_____________________________________________________________*/
  //NEW [2]Level [1]Type
  echo "<li><a id='folder' href='newfolder.php?level=2&contentlink=".$folder1."&type=1'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></li>";
  //[2]Level [1]Type
  $sql12 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 2 AND folder='.$folder1.'';
  $result12 = $db->query($sql12);
  if (!$result12) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row12 = $result12->fetch_assoc()) {
      $folder2 = $row12['id'];
      echo "
          <li>
            <a id='folder' href='#".$row12['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
            <a id='folderlink' href='?content=".$row12['id']."'><span class='text-primary'> ".$row12['content']."</span></a>
          </li>
          <ul class='collapse' id='".$row12['id']."'>";
/*_FOLDER LEVEL 3_____________________________________________________________*/
  //NEW [3]Level [1]Type
  echo "<li><a id='folder' href='newfolder.php?level=2&contentlink=".$folder2."&type=1'><i class='text-primary glyphicon glyphicon-plus'></i></a><span class='text-primary'> New Folder</span></li>";
  //[3]Level [1]Type
  $sql13 = 'SELECT * FROM contentassign WHERE type = 1 AND level = 3 AND folder='.$folder2.'';
  $result13 = $db->query($sql13);
  if (!$result13) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    //echo Content
    while ($row13 = $result13->fetch_assoc()) {
      $folder3 = $row13['id'];
      echo "
          <li>
            <a id='folder' href='#".$row13['id']."' data-toggle='collapse'><i class='text-primary glyphicon glyphicon-book'></i></a>
            <a id='folderlink' href='?content=".$row13['id']."'><span class='text-primary'> ".$row13['content']."</span></a>
          </li>
          <ul class='collapse' id='".$row13['id']."'>";

    echo "</ul>";
  } //__END FOLDER LVL 3__



    echo "</ul>";
  } //__END FOLDER LVL 2__


    echo "</ul>";
  } //__END FOLDER LVL 1__


    //CLOSE LIST
    echo "<p></ul></p>";

  } //__END FOLDER LVL 0__

}
  ?>
