<?php
require_once ("./connect.php");
require_once ("./nav/page.php");
if(!empty($_SESSION['login_user'])){
if(empty($_GET['search'])){
  $sql = 'SELECT * FROM contentassign WHERE folder = '.$folder.'';
  $result = $db->query($sql);
  if (!$result) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    echo "<table class='table' id='table'>";
    echo "<tr><tr>";
    echo "<tr>
            <th>Name</th>
            <th>Description</th>
          </tr>";
    while ($row = $result->fetch_assoc()) {
      echo "<tr>";
      echo "<th>
            <a id='tablefolder' class='btn' href='?content=".$row['id']."'><i class='glyphicon glyphicon-folder-close'></i> ".$row['content']."</a>
            </th>";
      echo "<th></th>";
      echo "</tr>";}
      echo "</table>";}}
?>
