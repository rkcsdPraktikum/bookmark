<?php
require_once ("./connect.php");
require_once ("./nav/page.php");
if(!empty($_SESSION['login_user'])){

if(empty($_GET['search'])){
  $sql = 'SELECT * FROM contentassign WHERE id = '.$folder.'';
  $result = $db->query($sql);
  if (!$result) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    while ($row = $result->fetch_assoc()) {
      $sql2 = 'SELECT * FROM contentassign WHERE id = '.$row['folder'].'';
      $result2 = $db->query($sql2);
      if (!$result2) {
        die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
        while ($row2 = $result2->fetch_assoc()) {
          echo "<a class='tablefolder btn' href='?content=".$row2['id']."'><i class='glyphicon glyphicon-share-alt'></i> ".$row2['content']."</a>";
    }}}}
?>
