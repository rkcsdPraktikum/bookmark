<?php
require_once("./connect.php");

$entrycount = 0;
if(!empty($_GET['content'])){
  $table = test_input($_GET['content']);
}
else {
  $table = "defaulttable";
}
$error = "
<div class='container'>
	<div class='containeook2/view.php?search=r row'>
	<div class='col-sm-10 col-sm-offset-2'>
	<a href='index.php'>
	<img class='img-thumbnail'  src='https://cdn.dribbble.com/users/605899/screenshots/4144886/pikabu.gif'>
</div>";
if(empty($_GET['search'])){
  $sql = 'SELECT * FROM `'.$table.'`';
  $result = $db->query($sql);
  if (!$result) {
    die (''.$error.'');}
    while ($row = $result->fetch_assoc())
      $entrycount++;
}
else {
  $search = test_input($_GET['search']);
  $sql = 'SELECT * FROM '.$table.' WHERE name LIKE "'.$search.'"';
  $result = $db->query($sql);
  if (!$result) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    while ($row = $result->fetch_assoc()) {
      $entrycount ++;}
}

if(!empty($_GET['page'])){
  $page = test_input($_GET['page']);
}
else {
  $page = 1;
}
if($entrycount == 0){
  $pagelimit = 1;
}
else{
  $pagelimit = ceil($entrycount / 10);
}
$offset = $page * 10 - 10;
?>
