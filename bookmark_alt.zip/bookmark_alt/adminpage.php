<?php
  include_once('./bootstraplink.php');
    if(!empty($_SESSION['login_user'])){
echo '<div class="jumbotron"></div>
<div class="container">
<div class="container row">
<div class="col-sm-3">
<div class="collapse" id="editor">
  <form class="" action="" target="_parent" method="get" >
    <div class="form-group well ">
      <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-bookmark"></i></span>
        <input class="form-control" name="newname" type="text" placeholder="Name">
        <input class="hidden" name="content" value="'.$table.'">
      </div>
      <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-globe"></i></span>
        <input type="url"  class="form-control" name="newurl"  placeholder="http://beispiel.com" required><br>
      </div>
      <br>
      <label for="comment">Bemerkung:</label>
      <textarea class="form-control" rows="5" name="comment" id="comment"></textarea>
      <br>
    <button class="btn btn-primary" type="submit" id="submit"><i class="glyphicon glyphicon-floppy-disk"></i> Save</button>
  </div>
  </form>
</div>
<div style="margin-bottom:-1.5em; background-color:#428bca;"class="well bg-primary"><h3 class=""><h2><strong>Verzeichnis</strong></h2></div>
<div style="margin-top:0;" class="well">
    <ul class="list-unstyled">';
       include("./folder.php");
       echo'
    </ul>
</div>
</div>';

echo '<div class="col-sm-9">';
include('./editform.php');
if(!empty($_GET['search']) && empty($_GET['id']) && empty($_GET['delid'])){include("search.php");}
if(!empty($_GET['delid']) or !empty($_GET['delete'])){require_once("delete.php");}
if(empty($_GET['newname'])){$_GET['newname']='unbenannt';}
if(empty($_GET['comment'])){$_GET['comment']='Es Würde Kein Bemerkung Hinzugefügt! ';}
if(!empty($_GET['newurl'])){require_once("save.php");}
if(!empty($_GET['editname']) or !empty($_GET['editurl'])){require_once("save.php");}
  echo '<div class="well">
  <table class="table table-striped" id="table">
    ';
    echo "<h2><i class='text-success glyphicon glyphicon-bookmark'> $table</i></h2> <tr>";
    include("./pagebar.php");
    echo  "</tr>
    <tr>";
    echo '</tr>
    <tr>
      <th><a data-target="#editor" data-toggle="collapse"><i class="glyphicon glyphicon-plus"></i></a></th>
      <th>Name</th>
      <th>URL</th>
      <th>Bemerkung</th>
      <th class="text-center">';
        echo '</th>
    </tr>';
    include('./admintable.php');
    echo "</table>
    </div>
    </div>
    </div>
    </div>";
  }
  if(empty($_SESSION['login_user'])){
     include ("./navbar.php");
    echo "<div id='profile' class='alert alert-success alert-warning'>
  <b class='glyphicon glyphicon-user'></b></b><b id='welcome' >Du Muass Anmelden um dieese seite  zu sehen!</b>
  </div>";
echo "<body onload=\"setTimeout('history.back()', 2000);\">";
  }
?>
