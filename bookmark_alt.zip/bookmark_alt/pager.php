<?php
require_once("./page.php");
//NO SEARCH
if (empty($_GET['search'])) {
      switch ($page) {
        case '1':
          echo "<a id='pagelimitjump' class='btn bg-info' disabled><i class='muted glyphicon glyphicon-menu-left'></i><i class='muted glyphicon glyphicon-menu-left'></i></a>";
          echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-chevron-left'></i></a>";
          break;
        default:
          $addpage = $page -1;
          echo "<a id='pagelimitjump' class='btn bg-info' href='?page=1&content=".$table."'><i class='glyphicon glyphicon glyphicon-menu-left'></i><i class='glyphicon glyphicon glyphicon-menu-left'></i></a>";
          echo "<a class='btn bg-info' href='?page=".$addpage."&content=".$table."'><i class='glyphicon glyphicon-chevron-left'></i></a>";
          break;
      }
      echo "<strong style='vertical-align: middle; padding: 0.2em;' class='well well-sm'>".$page."/".$pagelimit."</strong>";
      switch ($page) {
        case $pagelimit:
          echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-chevron-right'></i></a>";
          echo "<a id='pagelimitjump' class='btn bg-info' disabled><i class='muted glyphicon glyphicon-menu-right'></i><i class='muted glyphicon glyphicon-menu-right'></i></a>";
          break;
        default:
          $subpage = $page +1;
          echo "<a class='btn bg-info' href='?page=".$subpage."&content=".$table."'><i class='glyphicon glyphicon-chevron-right'></i></a>";
          echo "<a id='pagelimitjump' class='btn bg-info' href='?page=".$pagelimit."&content=".$table."'><i class='glyphicon glyphicon glyphicon-menu-right'></i><i class='glyphicon glyphicon glyphicon-menu-right'></i></a>";
          break;
      }}
//SEARCH
      else {
        switch ($page) {
          case '1':
            echo "<a id='pagelimitjump' class='btn bg-info' disabled><i class='muted glyphicon glyphicon-menu-left'></i><i class='muted glyphicon glyphicon-menu-left'></i></a>";
            echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-chevron-left'></i></a>";
            break;
          default:
            $addpage = $page -1;
            echo "<a id='pagelimitjump' class='btn bg-info' href='?page=1&search=".$search."&content=".$table."'><i class='glyphicon glyphicon glyphicon-menu-left'></i><i class='glyphicon glyphicon glyphicon-menu-left'></i></a>";
            echo "<a class='btn bg-info' href='?page=".$addpage."&search=".$_GET['search']."&content=".$table."'><i class='glyphicon glyphicon-chevron-left'></i></a>";
            break;
        }
        echo $page;
        switch ($page) {
          case $pagelimit:
            echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-chevron-right'></i></a>";
            echo "<a id='pagelimitjump' class='btn bg-info' disabled><i class='muted glyphicon glyphicon-menu-right'></i><i class='muted glyphicon glyphicon-menu-right'></i></a>";
            break;
          default:
            $subpage = $page +1;
            echo "<a class='btn bg-info' href='?page=".$subpage."&search=".$search."&content=".$table."'><i class='glyphicon glyphicon-chevron-right'></i></a>";
            echo "<a id='pagelimitjump' class='btn bg-info' href='?page=".$pagelimit."&search=".$search."&content=".$table."'><i class='glyphicon glyphicon glyphicon-menu-right'></i><i class='glyphicon glyphicon glyphicon-menu-right'></i></a>";
            break;
        }}
?>
