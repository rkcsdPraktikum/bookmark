<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">

  <title>bookmark</title>
  <style>
  </style>

</head>
<body style="background-color:#222222;">
<!--_NAVLEISTE_______________________________________________________________-->
<?php
  include_once('./page.php');
  include_once('./bootstraplink.php');
?>
<!--_JUMBOTRON_______________________________________________________________-->
<?php
  include('./login.php');
  if(!empty($_SESSION['login_user'])){
	   include ("./navbar.php");
     include('./adminpage.php');
  }
  if(empty($_SESSION['login_user'])){
	   include ("./navbar.php");
      echo "
        <div id='profile' class='alert alert-success alert-warning'>
        <b class='glyphicon glyphicon-user'></b></b><b id='welcome' >Du Muass Anmelden um dieese seite  zu sehen!</b>
        </div>";
      echo "
        <body onload=\"setTimeout('history.back()', 2000);\">";
  }
?>
<!--_MAINCONTAINER/ENDE______________________________________________________-->
</body>
</html>
