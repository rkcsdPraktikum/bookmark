<?php
require_once("./connect.php");

$entrycount = 0;
if(!empty($_GET['bookmarks'])){
  $table = test_input($_GET['bookmarks']);
}
else {
  $table = "defaulttable";
}
if(empty($_GET['search'])){
  $sql = 'SELECT * FROM '.$table.'';
  $result = $db->query($sql);
  if (!$result) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    while ($row = $result->fetch_assoc())
      $entrycount++;
}
else {
  $search = test_input($_GET['search']);
  $sql = 'SELECT * FROM '.$table.' WHERE name LIKE "'.$search.'"';
  $result = $db->query($sql);
  if (!$result) {
    die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
    while ($row = $result->fetch_assoc()) {
      $entrycount ++;}
}

if(!empty($_GET['page'])){
  $page = test_input($_GET['page']);
}
else {
  $page = 1;
}
if($entrycount == 0){
  $pagelimit = 1;
}
else{
  $pagelimit = ceil($entrycount / 10);
}
$offset = $page * 10 - 10;
?>
