
      <div id="pagebarcontainer" style="background-color:#D9EDF7;" class="container-fluid">
        <div>
        <div style="" class="col-sm-4">
          <form action="" class="" role="search">
            <div class="input-group">
              <input type="text" class="form-control" name="search" placeholder="Search...">
              <input type="text" class="hidden" name="bookmarks" value="<?php $table = test_input($_GET['bookmarks']); echo $table;?>">
              <span class="input-group-btn">
                <button class="btn btn-default" type="submit">
                  <span class="glyphicon glyphicon-search"></span>
                </button>
              </span>
            </div>
        	  </form>
        </div>
        <div class="text-center col-sm-4">
          <span>Test</span>
        </div>
        <div class="text-right col-sm-4">
          <?php
          require_once("./page.php");
          if (empty($_GET['search'])) {
                switch ($page) {
                  case '1':
                    echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-menu-left'></i><i class='muted glyphicon glyphicon-menu-left'></i></a>";
                    echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-chevron-left'></i></a>";
                    break;
                  default:
                    $addpage = $page -1;
                    echo "<a class='btn bg-info' href='?page=1&bookmarks=".$table."'><i class='glyphicon glyphicon glyphicon-menu-left'></i><i class='glyphicon glyphicon glyphicon-menu-left'></i></a>";
                    echo "<a class='btn bg-info' href='?page=".$addpage."&bookmarks=".$table."'><i class='glyphicon glyphicon-chevron-left'></i></a>";
                    break;
                }
                echo "<strong>".$page."</strong>";
                switch ($page) {
                  case $pagelimit:
                    echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-chevron-right'></i></a>";
                    echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-menu-right'></i><i class='muted glyphicon glyphicon-menu-right'></i></a>";
                    break;
                  default:
                    $subpage = $page +1;
                    echo "<a class='btn bg-info' href='?page=".$subpage."&bookmarks=".$table."'><i class='glyphicon glyphicon-chevron-right'></i></a>";
                    echo "<a class='btn bg-info' href='?page=".$pagelimit."&bookmarks=".$table."'><i class='glyphicon glyphicon glyphicon-menu-right'></i><i class='glyphicon glyphicon glyphicon-menu-right'></i></a>";
                    break;
                }}
                else {
                  switch ($page) {
                    case '1':
                      echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-menu-left'></i><i class='muted glyphicon glyphicon-menu-left'></i></a>";
                      echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-chevron-left'></i></a>";
                      break;
                    default:
                      $addpage = $page -1;
                      echo "<a class='btn bg-info' href='?page=1&search=".$search."&bookmarks=".$table."'><i class='glyphicon glyphicon glyphicon-menu-left'></i><i class='glyphicon glyphicon glyphicon-menu-left'></i></a>";
                      echo "<a class='btn bg-info' href='?page=".$addpage."&search=".$_GET['search']."&bookmarks=".$table."'><i class='glyphicon glyphicon-chevron-left'></i></a>";
                      break;
                  }
                  echo $page;
                  switch ($page) {
                    case $pagelimit:
                      echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-chevron-right'></i></a>";
                      echo "<a class='btn bg-info' disabled><i class='muted glyphicon glyphicon-menu-right'></i><i class='muted glyphicon glyphicon-menu-right'></i></a>";
                      break;
                    default:
                      $subpage = $page +1;
                      echo "<a class='btn bg-info' href='?page=".$subpage."&search=".$search."&bookmarks=".$table."'><i class='glyphicon glyphicon-chevron-right'></i></a>";
                      echo "<a class='btn bg-info' href='?page=".$pagelimit."&search=".$search."&bookmarks=".$table."'><i class='glyphicon glyphicon glyphicon-menu-right'></i><i class='glyphicon glyphicon glyphicon-menu-right'></i></a>";
                      break;
                  }}
          ?>
        </div>
      </div>
      </div>
